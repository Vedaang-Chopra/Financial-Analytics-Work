# Project Instructions for Coding Agents

## Purpose

This repository contains a phased implementation of an AMC-provider-first Indian mutual fund disclosure ingestion system.

The goal is to discover, download, parse, validate, and store public mutual fund investor disclosure data from Indian AMC/provider websites. The system should eventually populate PostgreSQL tables with structured holdings, factsheet, and disclosure data.

This is not a one-off scraper. It is a reproducible ingestion system with persistent website knowledge, measurable phase outputs, data-quality checks, and failure artifacts.

## Required Reading Before Implementation

Before modifying ingestion code, read:

1. `docs/design/mutual_fund_ingestion/00_project_overview.md`
2. `docs/design/mutual_fund_ingestion/01_system_architecture.md`
3. `docs/design/mutual_fund_ingestion/02_existing_codebase_audit.md`
4. `docs/design/mutual_fund_ingestion/03_data_artifacts_and_storage.md`
5. `docs/design/mutual_fund_ingestion/04_provider_profile_schema.md`
6. The relevant phase spec under `docs/design/mutual_fund_ingestion/phases/`

For Phase 1, read:

`docs/design/mutual_fund_ingestion/phases/phase_1_provider_profiling.md`

## Implementation Rules

Implement one phase at a time.

Do not build a monolithic scraper.

Do not assume all AMC websites use the same pattern.

Do not rely on AMFI as the primary source. AMC/provider websites are the primary sources.

Prefer extraction strategies in this order:

1. Static HTTP scraping
2. Network/API extraction
3. Deterministic Playwright browser automation
4. Local VLM/LLM-assisted recovery
5. Manual review report

Do not use VLM/LLM as the default path. Use it only for failed or ambiguous cases after deterministic methods are attempted.

Do not parse files in Phase 1.

Do not load PostgreSQL in Phase 1.

Do not build analytics in Phase 1.

Every phase must produce:

1. Machine-readable artifacts
2. Human-readable reports
3. Quantifiable metrics
4. Failure/debug artifacts

## Existing Codebase Policy

Before adding new code, inspect the existing codebase.

Identify reusable modules, including:

- previous AMFI or AMC crawler code
- download utilities
- parser utilities
- Excel/parquet/CSV tools
- PostgreSQL utilities
- CLI structure
- logging setup
- tests
- notebooks
- dataset folder contents

Reuse simple, tested, compatible code.

Do not delete existing code without documenting why.

If existing code is messy or incompatible, isolate it instead of rewriting the entire repository.

## Phase 1 Scope

Phase 1 is provider profiling only.

It should inspect each AMC seed URL and create persistent provider profiles that describe how each provider website exposes investor documents.

Phase 1 should answer:

- Is the website reachable?
- Are document links present in static HTML?
- Are links exposed through network/API calls?
- Is JavaScript required?
- Is Playwright required?
- Is a local VLM/browser recovery path likely required?
- What candidate document links can be found?
- What evidence was saved?

Phase 1 must not parse holdings or insert financial data into PostgreSQL.

## Reproducibility Principle

The system should not rediscover website behavior from scratch on every run.

Provider knowledge must be persisted in provider profile artifacts. Future phases should load the provider profiles and use the known successful strategy first. If it fails, the system should re-profile and update the profile.

## Safety and Compliance

Only ingest public investor disclosure documents.

Use polite crawling:

- request timeouts
- retry with backoff
- user-agent header
- sequential or low-concurrency downloads
- no CAPTCHA bypass
- no authentication bypass
- no scraping behind login walls

This system is for public disclosure analytics, not financial advice.
