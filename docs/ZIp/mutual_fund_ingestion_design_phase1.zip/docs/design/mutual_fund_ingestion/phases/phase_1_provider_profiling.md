# Phase 1 — AMC Provider Website Profiling

## Phase Goal

Build the first phase of the mutual fund ingestion system: provider website profiling.

Phase 1 should inspect each AMC/provider seed URL and determine how the website exposes investor documents.

The system should create persistent provider profiles that future phases can reuse.

Phase 1 does not download all documents, parse files, load PostgreSQL, or build analytics.

## Core Question

For each AMC/provider website:

```text
How should the ingestion system discover investor disclosure documents from this website in a reproducible way?
```

## Inputs

### 1. AMC Source Registry

Preferred location:

```text
configs/amc_sources.yaml
```

If this file does not exist, create it using the known AMC URLs.

Minimum schema:

```yaml
sources:
  - amc_name: "360 ONE Mutual Fund"
    seed_url: "https://www.360one.com/asset-management/mutual-fund/downloads/"
    enabled: true
    source_type: "provider_download_page"
    expected_document_types:
      - portfolio_disclosure
      - factsheet
    notes: ""
```

### 2. Existing Codebase

Before implementing, inspect existing code.

Follow:

```text
docs/design/mutual_fund_ingestion/02_existing_codebase_audit.md
```

Codex must produce an audit report before implementation.

## Outputs

### Machine-Readable Outputs

```text
data/raw/mutual_funds/provider_profiles/provider_profiles.jsonl
data/raw/mutual_funds/provider_profiles/provider_profiles.latest.json
```

### Human-Readable Outputs

```text
data/reports/mutual_funds/provider_profile_report.html
data/reports/mutual_funds/provider_profile_summary.csv
```

### Debug Outputs

```text
data/debug/mutual_funds/provider_profiles/<safe_amc_name>/
```

Potential debug files:

```text
static.html
rendered.html
screenshot.png
network_log.jsonl
accessibility_snapshot.json
profiler_error.json
```

## Phase 1 Strategy Order

For each provider, attempt profiling in this order:

### 1. Static HTML inspection

Use direct HTTP requests and HTML parsing.

Check:

- page status
- all `<a href>` links
- scripts
- forms
- direct file links
- candidate internal document pages

Look for file types:

```text
.pdf
.xls
.xlsx
.csv
.zip
```

Look for keywords:

```text
portfolio
disclosure
factsheet
fact sheet
statutory
ter
total expense ratio
sid
kim
scheme information document
key information memorandum
download
```

### 2. Network/API investigation

If static HTML suggests API-backed content, inspect likely scripts or endpoints.

The goal is not to reverse-engineer every site deeply in Phase 1, but to identify whether a direct network/API strategy is likely.

If clear API URLs or JSON endpoints are found, mark detected strategy as `network_api`.

### 3. Playwright rendering

If static inspection finds insufficient links or the page appears JavaScript-heavy, use Playwright.

Playwright should:

- open the seed URL
- wait for network idle or reasonable timeout
- capture rendered HTML
- capture screenshot
- extract links after rendering
- optionally inspect buttons/dropdowns/tabs
- avoid aggressive or random clicking in Phase 1

If Playwright reveals links, mark strategy as `playwright`.

### 4. VLM required / manual review

If the page visually contains relevant disclosure controls but deterministic extraction fails, mark as:

```text
vlm_required
```

If the page is unreachable, blocked, broken, or ambiguous, mark as:

```text
manual_review
```

Do not build the VLM agent in Phase 1. Only classify that it may be needed.

## Provider Profile Record

Use the schema from:

```text
docs/design/mutual_fund_ingestion/04_provider_profile_schema.md
```

Every provider must get a profile record, even if profiling fails.

Failures are not zero-link successes. Failures must be recorded explicitly.

## Quantifiable Metrics

Phase 1 report must include:

```text
total_amcs
profiled_successfully
partial_success
failed
manual_review_required
static_html_count
network_api_count
playwright_count
vlm_required_count
total_static_links_found
total_download_links_found
total_candidate_document_links_found
file_type_counts
```

## Visual / Manual Inspection Report

Generate a report that lets the user inspect profiling quality.

Minimum columns:

```text
AMC
Seed URL
Status
Detected Strategy
Requires JavaScript
Static Links Found
Download Links Found
Candidate Document Links Found
File Types Found
Failure Reason
Debug Folder
```

Prefer HTML. CSV fallback is acceptable.

## CLI Requirements

Add or reuse a CLI command.

Preferred command:

```bash
python -m mutual_fund_ingestion profile-sites
```

Alternative acceptable command if repository naming differs:

```bash
python -m amfi_disclosure profile-sites
```

Required options:

```bash
--limit N
--amc "HDFC Mutual Fund"
--force
--dry-run
--log-level INFO
--output-dir data/raw/mutual_funds/provider_profiles
```

Behavior:

- `--dry-run` should inspect and print/report results without writing persistent profile files.
- `--limit` should profile only the first N enabled sources.
- `--amc` should profile a specific AMC.
- `--force` should re-profile even if a previous profile exists.

## Existing Codebase Audit Requirement

Before Phase 1 implementation, Codex must:

1. Inspect existing repository.
2. Identify reusable code.
3. Write:

```text
docs/design/mutual_fund_ingestion/generated/existing_codebase_audit_report.md
```

4. Then implement Phase 1.

## Acceptance Criteria

Phase 1 is complete when:

1. The code can read AMC seed sources.
2. The code profiles each enabled AMC source.
3. Every AMC gets a provider profile record.
4. The profile records follow the defined schema.
5. Static HTML inspection works.
6. Playwright fallback works or is cleanly skipped if dependency is unavailable.
7. Debug artifacts are saved for failures or JS-heavy sites.
8. A human-readable report is generated.
9. Metrics are included in the report.
10. No parsing, downloading, PostgreSQL loading, or analytics are implemented beyond what is needed for profiling.

## Test Plan

Add tests where practical.

Suggested tests:

```text
test_source_registry_loads
test_provider_profile_schema_validation
test_static_html_link_extraction_from_fixture
test_file_type_detection
test_document_type_hint_detection
test_safe_amc_name_generation
test_report_generation_from_profiles
```

Live smoke test:

```bash
python -m mutual_fund_ingestion profile-sites --limit 3
```

Expected live smoke test result:

- at least 3 provider profile records
- report generated
- debug artifacts created when needed
- no unhandled exceptions

## Out of Scope

Phase 1 must not implement:

- full document downloading
- Excel parsing
- PDF parsing
- PostgreSQL loading
- financial analytics
- investment advice
- autonomous VLM browser control
- monthly scheduling
- full AMFI ingestion
